import os
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pymongo import MongoClient

# ==============================
# MongoDB Atlas Connection
# ==============================
MONGO_URL = "mongodb+srv://naiknimisha2007_db_user:NaiknimishaDB08@smartfirstaidcluster.b8w3m7q.mongodb.net/SmartFirstAidDB?retryWrites=true&w=majority"
client = MongoClient(MONGO_URL, tls=True)
db = client["SmartFirstAidDB"]
collection = db["injuries_structured"]  # <-- Your 1000+ tips collection

# ==============================
# FastAPI App
# ==============================
app = FastAPI(title="AI Cloud Smart First Aid System", version="2.0")

# ==============================
# CORS (allow frontend requests)
# ==============================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For dev only, restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==============================
# Existing Endpoints
# ==============================
@app.get("/firstaid/guidance", tags=["firstaid"])
def guidance():
    data = list(collection.find({}, {"_id": 0, "condition": 1, "solution": 1}))
    return JSONResponse(content=data)

@app.get("/firstaid/symptoms", tags=["firstaid"])
def symptoms():
    data = list(collection.find({}, {"_id": 0, "condition": 1, "symptoms": 1}))
    return JSONResponse(content=data)

@app.get("/firstaid/treatment", tags=["firstaid"])
def treatment():
    data = list(collection.find({}, {"_id": 0, "condition": 1, "solution": 1}))
    return JSONResponse(content=data)

# ==============================
# 🔹 Full Search Endpoint for frontend search bar
# ==============================
@app.get("/search/", tags=["firstaid"])
def search_injury(q: str = Query(..., description="Search first aid tip by name or description")):
    results = list(
        collection.find(
            {
                "$or": [
                    {"name": {"$regex": q, "$options": "i"}},
                    {"description": {"$regex": q, "$options": "i"}}
                ]
            }
        )
    )
    for r in results:
        r["_id"] = str(r["_id"])
    return results

# ==============================
# 🔹 Single Injury Endpoint (case-insensitive partial match)
# ==============================
@app.get("/injury/{name}", tags=["firstaid"])
def get_injury(name: str):
    injury = collection.find_one({"name": {"$regex": name, "$options": "i"}})
    if injury:
        injury["_id"] = str(injury["_id"])
        return injury
    return {"error": "Injury not found"}

# ==============================
# 🔹 Optional test endpoint to verify DB connection
# ==============================
@app.get("/test")
def test_db():
    doc = collection.find_one()
    if doc:
        doc["_id"] = str(doc["_id"])
        return doc
    return {"error": "No documents found"}